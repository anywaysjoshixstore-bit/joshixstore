SAHIL JOSHI STORE — NEW VERCEL PROJECT PACKAGE

FILES
- index.html          Main customer website
- admin/index.html    Separate full-screen Firebase admin panel
- vercel.json         Vercel route for /admin and /admin/
- firebase.json       Optional Firebase Hosting config (not required by Vercel)

VERCEL URLS
- https://YOUR-NEW-PROJECT.vercel.app/
- https://YOUR-NEW-PROJECT.vercel.app/admin/

ADMIN LOGIN FIX INCLUDED
- Admin access is checked against the currently signed-in Firebase Auth user.
- The admin UI waits for Firebase Auth session restoration and then refreshes.
- Save guards use the Firebase Auth user rather than a stale JavaScript boolean.
- Logout signs out of Firebase Authentication.
- Cloud save helpers reject writes when the admin Firebase session is not active.

FIREBASE SETUP REQUIRED BEFORE TESTING
1. In Firebase Console > Authentication > Sign-in method, enable Email/Password.
2. Create/confirm the admin Authentication user with this exact email:
   admin@sahiljoshistore.com
3. Authentication > Settings > Authorized domains: add your NEW Vercel domain.
4. Confirm the Realtime Database and Storage are enabled in project:
   joshixstore-e9b9f
5. Configure secure Realtime Database and Storage Rules. Do NOT use public read/write rules.
   Client-side checks are for UI only; Firebase Rules are the actual security boundary.
6. Deploy the CONTENTS of this folder as the root of a NEW Vercel project.
   Preserve the admin/ folder and its index.html file.

IMPORTANT LIMITATIONS
- The code has been syntax-checked, but cannot be authenticated against your live Firebase account or tested against your live database/rules from this environment.
- Existing data schema and Firebase Rules can affect individual features. Test admin login, save, image upload, order updates, and customer-side live refresh after deployment.
- Do not use this package for real payments or balances until server-side validation and database rules have been reviewed and tested.
